// ฟังก์ชันช่วยคำนวณสถานะจากค่า AQI
function getAQIStatus(pm25) {
    if (pm25 <= 50) return { color: "#66BB6A", text: "ดี - Good", desc: "💡 แนะนำ: อากาศดีมาก เหมาะแก่การทำกิจกรรมกลางแจ้ง" };
    if (pm25 <= 100) return { color: "#FFA726", text: "ปานกลาง - Moderate", desc: "💡 แนะนำ: คุณภาพอากาศปานกลาง กลุ่มเสี่ยงควรลดกิจกรรมหนัก" };
    return { color: "#EF5350", text: "เริ่มมีผลกระทบ - Unhealthy", desc: "💡 แนะนำ: ควรใส่หน้ากาก และหลีกเลี่ยงที่แจ้งเป็นเวลานาน" };
}

// Template ใหม่ (สภาพอากาศ + AQI)
const createWeatherFlex = (data) => {
    const status = getAQIStatus(data.pm25);
    
    return {
        type: "flex",
        altText: "รายงานสภาพอากาศและ PM2.5",
        contents: {
            type: "bubble",
            size: "mega",
            header: {
                type: "box",
                layout: "vertical",
                contents: [
                    { type: "text", text: "สภาพอากาศและค่าฝุ่น", color: "#ffffff", size: "xl", weight: "bold" },
                    { type: "text", text: `${data.place}, Thailand`, color: "#ffffff", size: "sm", margin: "xs" }
                ],
                backgroundColor: "#4A90E2",
                paddingAll: "20px"
            },
            body: {
                type: "box",
                layout: "vertical",
                contents: [
                    {
                        type: "box",
                        layout: "horizontal",
                        contents: [
                            { type: "box", layout: "vertical", contents: [{ type: "text", text: "🌤️", size: "5xl", align: "center" }], flex: 1 },
                            {
                                type: "box",
                                layout: "vertical",
                                contents: [
                                    { type: "text", text: `${data.temp}°C`, size: "4xl", weight: "bold", color: "#333333" },
                                    { type: "text", text: `ความชื้น ${data.humidity}%`, size: "sm", color: "#999999", margin: "xs" }
                                ],
                                flex: 2
                            }
                        ],
                        margin: "lg"
                    },
                    { type: "separator", margin: "xl" },
                    {
                        type: "box",
                        layout: "vertical",
                        contents: [
                            {
                                type: "box",
                                layout: "horizontal",
                                contents: [
                                    { type: "text", text: "🌬️ ลม", size: "sm", color: "#555555", flex: 3 },
                                    { type: "text", text: `${data.windSpeed} m/s`, size: "sm", color: "#111111", align: "end", weight: "bold", flex: 2 }
                                ],
                                margin: "md"
                            }
                        ]
                    },
                    { type: "separator", margin: "xl" },
                    {
                        type: "box",
                        layout: "vertical",
                        contents: [
                            { type: "text", text: "คุณภาพอากาศ (US AQI)", size: "lg", weight: "bold", color: "#333333", margin: "md" },
                            {
                                type: "box",
                                layout: "vertical",
                                contents: [
                                    {
                                        type: "box",
                                        layout: "horizontal",
                                        contents: [
                                            { type: "text", text: "AQI (US)", size: "xl", weight: "bold", color: "#ffffff" },
                                            { type: "text", text: `${data.pm25}`, size: "3xl", weight: "bold", color: "#ffffff", align: "end" }
                                        ]
                                    },
                                    { type: "text", text: status.text, size: "sm", color: "#ffffff", margin: "sm" }
                                ],
                                backgroundColor: status.color,
                                cornerRadius: "lg",
                                paddingAll: "15px",
                                margin: "md"
                            }
                        ]
                    },
                    {
                        type: "box",
                        layout: "vertical",
                        contents: [{ type: "text", text: status.desc, size: "xs", color: "#666666", wrap: true }],
                        backgroundColor: "#F5F5F5", cornerRadius: "md", paddingAll: "12px", margin: "xl"
                    }
                ],
                paddingAll: "20px"
            },
            footer: {
                type: "box",
                layout: "vertical",
                contents: [{ type: "text", text: `อัพเดท: ${data.time}`, size: "xs", color: "#999999", align: "center" }],
                paddingAll: "12px"
            }
        }
    };
};

module.exports = { createWeatherFlex };